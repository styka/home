import {Activity} from './activity';

describe('Activity', () => {

  it('should create an instance', () => {
    expect(new Activity()).toBeTruthy();
  });

  it('should accept values in the constructor', () => {
    let activity = new Activity({
      title: 'hello',
      id: 1
    });
    expect(activity.title).toEqual('hello');
    expect(activity.id).toEqual(1);
  });

});
