export class Activity {
  id: number;
  title: string = '';
  description: string = '';
  status: string = '';
  date: string = '';
  asiaTime: number;
  szymonTime: number;

  constructor(values: Object = {}) {
    Object.assign(this, values);
  }
}
