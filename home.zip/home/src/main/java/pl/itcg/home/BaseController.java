package pl.itcg.home;

public class BaseController {
    public static final String BASE_CONTEXT = "api/v1/";
}
