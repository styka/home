package pl.itcg.home.activity;

public enum ActivityStatus {
    DRAFT, PATTERN, WAITING, DONE, NOT_DONE
}
